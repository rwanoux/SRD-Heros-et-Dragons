# SRD pour héros et dragon

## soyez vigilant,

### les valeurs des compétences ne sont pas respéctées pour les monstres....
### les actions et feat des monstres ne sont pas créées mais leur description est renseignée dans l'onglet "biographie"
## voilà !